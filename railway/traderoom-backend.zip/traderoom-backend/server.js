const express = require('express')
const http = require('http')
const { Server } = require('socket.io')
const cors = require('cors')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const { createClient } = require('@supabase/supabase-js')

const app = express()
const server = http.createServer(app)
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
})

// ── CONFIG ──
const SUPABASE_URL = 'https://btqgizadenxvgnybjifx.supabase.co'
const SUPABASE_KEY = 'sb_publishable_lpcSO7-IQJL0g2pF3UgQLw_AneC6pXw'
const JWT_SECRET   = 'traderoom_jwt_secret_2025'
const PORT         = process.env.PORT || 3001

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY)

app.use(cors())
app.use(express.json())

// ── MIDDLEWARE AUTH ──
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ erro: 'Token obrigatório' })
  try {
    req.user = jwt.verify(token, JWT_SECRET)
    next()
  } catch {
    res.status(401).json({ erro: 'Token inválido' })
  }
}

// ══════════════════════════════════════════════
// ROTAS DE AUTENTICAÇÃO
// ══════════════════════════════════════════════

// CADASTRO
app.post('/auth/cadastro', async (req, res) => {
  try {
    const { email, senha, trader_id } = req.body
    if (!email || !senha || !trader_id)
      return res.status(400).json({ erro: 'Email, senha e trader_id obrigatórios' })

    // Verificar se email já existe
    const { data: emailExiste } = await supabase
      .from('usuarios').select('id').eq('email', email).single()
    if (emailExiste) return res.status(400).json({ erro: 'Email já cadastrado' })

    // Verificar se trader_id já existe
    const { data: idExiste } = await supabase
      .from('usuarios').select('id').eq('trader_id', trader_id).single()
    if (idExiste) return res.status(400).json({ erro: 'ID já em uso, escolha outro' })

    const senha_hash = await bcrypt.hash(senha, 10)
    const { data, error } = await supabase.from('usuarios').insert({
      email, senha_hash, trader_id
    }).select().single()

    if (error) return res.status(500).json({ erro: error.message })

    const token = jwt.sign({ id: data.id, trader_id: data.trader_id }, JWT_SECRET, { expiresIn: '30d' })
    res.json({ token, trader_id: data.trader_id, id: data.id })
  } catch (e) {
    res.status(500).json({ erro: e.message })
  }
})

// LOGIN
app.post('/auth/login', async (req, res) => {
  try {
    const { email, senha } = req.body
    const { data: user } = await supabase
      .from('usuarios').select('*').eq('email', email).single()
    if (!user) return res.status(400).json({ erro: 'Email ou senha incorretos' })

    const ok = await bcrypt.compare(senha, user.senha_hash)
    if (!ok) return res.status(400).json({ erro: 'Email ou senha incorretos' })

    // Atualizar último acesso
    await supabase.from('usuarios').update({ ultimo_acesso: new Date() }).eq('id', user.id)

    const token = jwt.sign({ id: user.id, trader_id: user.trader_id }, JWT_SECRET, { expiresIn: '30d' })
    res.json({ token, trader_id: user.trader_id, id: user.id })
  } catch (e) {
    res.status(500).json({ erro: e.message })
  }
})

// ══════════════════════════════════════════════
// ROTAS DE SALAS
// ══════════════════════════════════════════════

// LISTAR SALAS
app.get('/salas', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('salas')
      .select(`*, criador:usuarios(trader_id)`)
      .eq('ativa', true)
      .order('fake', { ascending: true })
      .order('criado_em', { ascending: false })
    if (error) return res.status(500).json({ erro: error.message })
    res.json(data)
  } catch (e) {
    res.status(500).json({ erro: e.message })
  }
})

// CRIAR SALA
app.post('/salas', authMiddleware, async (req, res) => {
  try {
    const { nome, ativos, mercado, limite } = req.body
    const { data, error } = await supabase.from('salas').insert({
      nome, ativos, mercado,
      limite: limite || 10,
      criador_id: req.user.id,
      fake: false
    }).select().single()
    if (error) return res.status(500).json({ erro: error.message })
    res.json(data)
  } catch (e) {
    res.status(500).json({ erro: e.message })
  }
})

// ENTRAR EM SALA
app.post('/salas/:id/entrar', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params
    const { data: sala } = await supabase.from('salas').select('*, sala_membros(count)').eq('id', id).single()
    if (!sala) return res.status(404).json({ erro: 'Sala não encontrada' })
    if (sala.fake) return res.status(400).json({ erro: 'Sala indisponível' })

    const { data: membros } = await supabase.from('sala_membros').select('id').eq('sala_id', id)
    if (membros.length >= sala.limite) return res.status(400).json({ erro: 'Sala cheia' })

    await supabase.from('sala_membros').upsert({ sala_id: id, usuario_id: req.user.id })
    res.json({ ok: true })
  } catch (e) {
    res.status(500).json({ erro: e.message })
  }
})

// ══════════════════════════════════════════════
// ROTAS DE ADMIN
// ══════════════════════════════════════════════

app.get('/admin/usuarios', async (req, res) => {
  const senha = req.headers['x-admin-senha']
  if (senha !== 'traderoom2025') return res.status(401).json({ erro: 'Não autorizado' })
  const { data } = await supabase.from('usuarios').select('id, email, trader_id, criado_em, ultimo_acesso').order('criado_em', { ascending: false })
  res.json(data)
})

// ══════════════════════════════════════════════
// WEBSOCKET — CHAT EM TEMPO REAL
// ══════════════════════════════════════════════

const salasAtivas = {} // { salaId: Set(socketIds) }

io.on('connection', (socket) => {
  console.log('Socket conectado:', socket.id)

  // Entrar na sala
  socket.on('entrar_sala', ({ salaId, trader_id }) => {
    socket.join(salaId)
    socket.trader_id = trader_id
    socket.salaId = salaId
    if (!salasAtivas[salaId]) salasAtivas[salaId] = new Set()
    salasAtivas[salaId].add(socket.id)

    // Avisar todos na sala
    io.to(salaId).emit('sistema', { msg: `${trader_id} entrou na sala` })
    io.to(salaId).emit('membros_count', salasAtivas[salaId].size)
  })

  // Mensagem no chat
  socket.on('mensagem', async ({ salaId, conteudo, usuario_id }) => {
    const msg = {
      trader_id: socket.trader_id,
      conteudo,
      hora: new Date().toLocaleTimeString('pt-BR')
    }
    // Salvar no banco
    await supabase.from('mensagens').insert({ sala_id: salaId, usuario_id, conteudo })
    // Transmitir para todos na sala
    io.to(salaId).emit('mensagem', msg)
  })

  // Desconexão
  socket.on('disconnect', () => {
    if (socket.salaId && salasAtivas[socket.salaId]) {
      salasAtivas[socket.salaId].delete(socket.id)
      io.to(socket.salaId).emit('sistema', { msg: `${socket.trader_id} saiu da sala` })
      io.to(socket.salaId).emit('membros_count', salasAtivas[socket.salaId].size)
    }
  })
})

// ── START ──
server.listen(PORT, () => console.log(`TradeRoom backend rodando na porta ${PORT}`))
